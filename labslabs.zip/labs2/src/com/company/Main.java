package com.company;

public class Main {
    public static void main(String args[]) {
        GUI app = new GUI();
        app.setVisible(true);

    }
}
